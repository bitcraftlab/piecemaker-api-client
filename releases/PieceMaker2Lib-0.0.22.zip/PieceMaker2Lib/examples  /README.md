Processing (Java / JS) examples
===============================

These examples should run in both Processing default (Java) and 
JavaScript mode. Later can be installed through the "Modes" menu 
at the top-right in any PDE windows.

JavaScript mode is documented here:
https://github.com/fjenett/javascript-mode-processing

